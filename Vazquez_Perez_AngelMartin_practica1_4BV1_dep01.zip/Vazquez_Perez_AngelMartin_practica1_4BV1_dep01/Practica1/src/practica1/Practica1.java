package practica1;

import vista.FrameCompleto;

/**
 *
 * @author jhona
 */
public class Practica1 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        new FrameCompleto();
    }
    
}
